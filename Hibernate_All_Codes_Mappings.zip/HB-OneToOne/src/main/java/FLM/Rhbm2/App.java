package FLM.Rhbm2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		SessionFactory sessionFactory = buildSessionFactoryObject();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

//		insert(session);
		
		Person sureshData = session.get(Person.class, 2);
System.out.println(sureshData);
		transaction.commit();

		session.close();
		System.out.println("Bye");

	}

	private static void insert(Session session) {
		Person p4 = new Person();
		Aadhar a4=new Aadhar();
		a4.setAadharNumber(2324);
		p4.setName("Srija A");
		p4.setAadharId(a4);
		
		session.save(p4);
	}

	private static void readOps(Session session) {
		Person student = session.get(Person.class, 2);

		student.setName("Suresh M");
		Aadhar aadhar = student.getAadharId();
		aadhar.setAadharNumber(9848);
		student.setAadharId(aadhar);
		session.save(student);
		System.out.println(student);
//       session.delete(student);
	}

	private static org.hibernate.SessionFactory buildSessionFactoryObject() {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(Student.class).addAnnotatedClass(Address.class).addAnnotatedClass(Person.class)
				.addAnnotatedClass(Aadhar.class);
//		.
//		addAnnotatedClass(Customer.class).
//		addAnnotatedClass(ShippingAddress.class)
		;
		org.hibernate.SessionFactory sessionFactoryObject = cfg.buildSessionFactory();
		return sessionFactoryObject;
	}

}
