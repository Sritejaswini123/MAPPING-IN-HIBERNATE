package FLM.Rhbm2;

import java.util.Arrays;
import java.util.List;

// Main.java
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {
	public static void main(String[] args) {
        try  {
        	SessionFactory factory = getSfactory();

            // Create session
            Session session = factory.openSession();

            // Start transaction
            session.beginTransaction();

//            saveOps(session);
//            readOps(session);
//            updateOp(session);
//            deleteOps(session);
            

            // Commit transaction
            session.getTransaction().commit();

            System.out.println("Data saved successfully!");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

	private static void deleteOps(Session session) {
		Teacher teacher = session.get(Teacher.class, 3L);
		session.delete(teacher);
	}

	private static void updateOp(Session session) {
		Teacher teacher = session.get(Teacher.class, 3L);
		teacher.setName("KKD");
	}

	private static void readOps(Session session) {
		Teacher teacher = session.get(Teacher.class, 3L);
		System.out.println(teacher.getName());
		List<Subject> subjects = teacher.getSubjects();
		subjects.forEach(sub -> System.out.println(sub.getName()));
	}

	private static void saveOps(Session session) {
		// Create teachers
		Teacher teacher1 = new Teacher();
		teacher1.setName("Mr. John");

		Teacher teacher2 = new Teacher();
		teacher2.setName("Mrs. Smith");

		// Create subjects
		Subject subject1 = new Subject();
		subject1.setName("History");

		Subject subject2 = new Subject();
		subject2.setName("Geography");

		// Associate teachers with subjects
		teacher1.setSubjects(Arrays.asList(subject1, subject2));
		teacher2.setSubjects(Arrays.asList(subject2));

		// Save teachers and subjects
		
		session.save(subject1);
		session.save(subject2);
		session.save(teacher1);
		session.save(teacher2);
	}

	private static SessionFactory getSfactory() {
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml")
		        .addAnnotatedClass(Teacher.class).addAnnotatedClass(Subject.class).buildSessionFactory();
		return factory;
	}
}
