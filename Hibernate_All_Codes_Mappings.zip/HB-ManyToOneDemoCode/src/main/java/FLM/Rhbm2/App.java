package FLM.Rhbm2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        SessionFactory sessionFactory = buildSessionFactoryObject();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        Person student = session.get(Person.class, 2);
        student.setName("Suresh D");
        Aadhar aadhar = student.getAadharId();
        aadhar.setAadharNumber(9848);
        student.setAadharId(aadhar);
        session.save(student);
       System.out.println(student);
//       session.delete(student);
       transaction.commit();
       
        session.close();
        System.out.println("Bye");
        
    }
    
    private static org.hibernate.SessionFactory buildSessionFactoryObject() {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(Student.class)
		.addAnnotatedClass(Address.class)
		.addAnnotatedClass(Person.class)
		.addAnnotatedClass(Aadhar.class)
		.addAnnotatedClass(Orders.class)
		.addAnnotatedClass(Customer.class);
//		.
//		addAnnotatedClass(Customer.class).
//		addAnnotatedClass(ShippingAddress.class)
		;
		org.hibernate.SessionFactory sessionFactoryObject = cfg.buildSessionFactory();
		return sessionFactoryObject;
	}

}
