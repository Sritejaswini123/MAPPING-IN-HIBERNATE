package com.flm;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class App {
	public static void main(String[] args) {
		Session session = getSession();
		//get session
		
		Query query = session.getNamedQuery("all");
//		Query query = session.createQuery("from Student", Student.class);
		List list = query.list();
		System.out.println(list);

		commitAndCloseSession(session);
		System.out.println("Ok Bye !!");

	}

	private static void deleteCustomer(Session session) {
		Customer c = new Customer();
		c.setId(1L);
		session.delete(c);
	}

	private static Customer createCustomerObject() {
		// Create a new customer with a shipping address
		Customer customer = new Customer();
		customer.setName("Alice Smith");

		ShippingAddress shippingAddress = new ShippingAddress();
		shippingAddress.setStreet("456 Elm St");
		shippingAddress.setCity("Los Angeles");
		shippingAddress.setZipCode("90001");

		customer.setShippingAddress(shippingAddress);

		return customer;
	}

	private static Session getSession() {
		org.hibernate.SessionFactory sessionFactoryObject = buildSessionFactoryObject();
		Session session = getSessionAndBeginTx(sessionFactoryObject);
		return session;
	}

	private static void commitAndCloseSession(Session session) {
		session.getTransaction().commit(); // ctrl+s
		session.close();
	}

	private static Session getSessionAndBeginTx(org.hibernate.SessionFactory sessionFactoryObject) {
		Session session = sessionFactoryObject.openSession();
		session.beginTransaction();
		return session;
	}

	private static void namedQuery(Session session) {
		// session.get(Student.class,1);
		// HQL you can write own queries using hibernate

		// A A N

		session.createNamedQuery("all_customers").list().forEach(System.out::print);
	}

	private static void readStudentData(Session session) {
		Query<Student> query = session.createNativeQuery(
				"select * from Student_Info s where s.student_name=:name and s.id=:id", Student.class);
		query.setParameter("name", "Dinesh");
		query.setParameter("id", 5);
		List studentData = query.list();
		System.out.println(studentData);
	}

	private static Student createAObject() {
		Student s3 = new Student();
		s3.setName("Nayan");
		s3.setQualification("BusinessMan-1");
		return s3;
	}

	private static void detachDemo(Student s3, Session session) {
		session.save(s3); // Lead-1 Lead-2

		session.detach(s3);
		s3.setQualification("BusinessMan-2"); // Dirty Checking
	}

	private static org.hibernate.SessionFactory buildSessionFactoryObject() {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(Student.class).addAnnotatedClass(Customer.class).addAnnotatedClass(ShippingAddress.class);
		org.hibernate.SessionFactory sessionFactoryObject = cfg.buildSessionFactory();
		return sessionFactoryObject;
	}

	private static void hibernateCRUDoperations(Session session) {
		session.save(null); // Create Operation
		Student ananddata = session.get(Student.class, 100);
		ananddata.setQualification("Phd");
		session.update(ananddata); // Update
		System.out.println(ananddata);
		Student sivaData = session.get(Student.class, 1434); // Read Operation
		session.delete(sivaData); // Delete
	}

	private static Student createAStudentObject() {
		// Session

		Student s = new Student();
		s.setId(143456);
		s.setName("Balu");
		s.setQualification("Btech");

		// url
		// uname
		// pw
		return s;
	}
}
