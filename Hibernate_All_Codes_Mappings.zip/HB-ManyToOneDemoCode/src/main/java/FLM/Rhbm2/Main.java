package FLM.Rhbm2;

import java.util.Arrays;
import java.util.List;

// Main.java
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {
	public static void main(String[] args) {
		try {

			// Create session
			Session session = buildSessionFactoryObject().openSession();

			// Start transaction
			session.beginTransaction();

//            createOps(session);

//            readFromEmployee(session);

//			readFromDeptSide(session);

//			updateEmployeeAndDept(session);

//			deleteEmployee(session);

//			updateDept(session);

//			deleteFromDept(session);
			// Commit transaction

			session.getTransaction().commit();

			System.out.println("Data saved successfully!");

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private static void deleteFromDept(Session session) {
		Department department = session.get(Department.class, 3L);
		session.delete(department);
	}

	private static void updateDept(Session session) {
		Department department = session.get(Department.class, 2L);
		department.setName("Innnfra");
	}

	private static void deleteEmployee(Session session) {
		Employee employee = session.get(Employee.class, 1L);
		session.delete(employee);
	}

	private static void updateEmployeeAndDept(Session session) {
		Employee employee = session.get(Employee.class, 1L);
		employee.setName("Karthik KK");
		Department d6 = new Department();
		d6.setName("HR ops");
		session.save(d6);
		employee.setDepartment(d6);
	}

	private static void readFromDeptSide(Session session) {
		Department department = session.get(Department.class, 2L);
		System.out.println(department.getName());
		List<Employee> employees = department.getEmployees();
		employees.forEach(emp -> System.out.println(emp.getName()));
	}

	private static void readFromEmployee(Session session) {
		Employee employee = session.get(Employee.class, 3L);

		System.out.println(employee.getName());
		System.out.println(employee.getDepartment().getName());
	}

	private static void createOps(Session session) {
		// Create a department
		Department department = new Department();
		department.setName("IT");

		// Create employees
		Employee employee1 = new Employee();
		employee1.setName("John Doe");
		employee1.setDepartment(department);

		Employee employee2 = new Employee();
		employee2.setName("Jane Smith");
		employee2.setDepartment(department);

		// Add employees to department
		department.setEmployees(Arrays.asList(employee1, employee2));

		// Save department (and cascaded employees)
		session.save(department);
	}

	private static org.hibernate.SessionFactory buildSessionFactoryObject() {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(Employee.class).addAnnotatedClass(Department.class)
//		.addAnnotatedClass(Person.class)
//		.addAnnotatedClass(Aadhar.class)
//		.addAnnotatedClass(Orders.class)
//		.addAnnotatedClass(Customer.class);
//		.
//		addAnnotatedClass(Customer.class).
//		addAnnotatedClass(ShippingAddress.class)
		;
		org.hibernate.SessionFactory sessionFactoryObject = cfg.buildSessionFactory();
		return sessionFactoryObject;
	}

}
