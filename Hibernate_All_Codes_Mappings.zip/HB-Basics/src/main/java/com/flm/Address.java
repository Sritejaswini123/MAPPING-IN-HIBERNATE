package com.flm;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
	
	private int dNo;
	
	private String city;

	public int getdNo() {
		return dNo;
	}

	public void setdNo(int dNo) {
		this.dNo = dNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	

}
