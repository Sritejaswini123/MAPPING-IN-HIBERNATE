package com.flm;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity // 1
@Table(name = "Student_Info")
@NamedQuery(name = "all",query = "from Student")
public class Student {
	
	@Id // 2 PK
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "student_name",length = 40,nullable = false)
	private String name;
	
//	@Column(name = "student_qualification")
	private String qualification;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	
	

	
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", qualification=" + qualification + "]";
	}

	public Student(int id, String name, String qualification) {
		this.id = id;
		this.name = name;
		this.qualification = qualification;
	}

	public Student() {
	}
	
	

}
